define({
    name: 'c'
});
