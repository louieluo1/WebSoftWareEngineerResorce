define(["require","exports","module"], function () {
    return {
        name: 'b3'
    };
});
