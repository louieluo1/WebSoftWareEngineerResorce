define("foo/bar/two", {
    name: "two"
});
