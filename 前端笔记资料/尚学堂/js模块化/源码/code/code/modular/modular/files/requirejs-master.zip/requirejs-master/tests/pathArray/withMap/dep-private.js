define(['dep'], function(d) {
  return d;
});
