define(["require","exports","module","./b/3"], function (r, e, m, b3) {
    return {
        name: 'two',
        b3: b3
    };
})
