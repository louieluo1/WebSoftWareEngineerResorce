define(function (require, exports, module) {
    return {
        apiKey: module.config().apiKey
    };
});
