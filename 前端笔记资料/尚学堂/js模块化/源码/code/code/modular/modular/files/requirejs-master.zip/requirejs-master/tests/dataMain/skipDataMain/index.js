define('index', ['a'], function (a) {
    a.modified = true;
});
