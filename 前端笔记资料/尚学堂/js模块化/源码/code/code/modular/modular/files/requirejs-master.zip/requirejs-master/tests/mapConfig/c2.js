define({
    name: 'c2'
});
