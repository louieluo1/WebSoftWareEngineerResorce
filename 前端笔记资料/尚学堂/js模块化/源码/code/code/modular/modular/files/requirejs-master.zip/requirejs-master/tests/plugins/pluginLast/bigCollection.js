define(['collection', 'text!bigCollection.html'], function (collection, html) {
    return {
        name: 'bigCollection',
        html: html,
        collection: collection
    };
});