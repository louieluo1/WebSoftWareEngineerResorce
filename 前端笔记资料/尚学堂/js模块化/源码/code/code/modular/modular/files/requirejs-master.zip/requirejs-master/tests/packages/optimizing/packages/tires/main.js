define({
    name: 'tires'
});