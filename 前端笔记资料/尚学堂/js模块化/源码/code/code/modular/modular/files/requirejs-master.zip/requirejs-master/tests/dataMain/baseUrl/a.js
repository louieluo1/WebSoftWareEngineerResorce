define({
    name: 'a'
});

