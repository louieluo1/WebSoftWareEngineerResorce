define(["jquery.alpha", "jquery.beta"], function() {});
