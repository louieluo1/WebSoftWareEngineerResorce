define({
    load: function(name, req, load) {
        req([name], load);
    }
});
